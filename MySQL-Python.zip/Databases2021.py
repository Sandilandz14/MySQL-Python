from tkinter import *
import mysql.connector
from tkinter import messagebox
import tkinter as tk


root = Tk()
root.title("Lifechoices Management System:")
root.geometry("400x400")


root.mainloop()
